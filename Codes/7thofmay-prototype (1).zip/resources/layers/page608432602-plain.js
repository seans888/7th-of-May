rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__page608432602-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page608432602" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page608432602-layer-icon354432494" style="position: absolute; left: 35px; top: 275px; width: 32px; height: 32px" data-stencil-type="fonticon.icon" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon354432494" data-review-reference-id="icon354432494">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" xmlns="http://www.w3.org/1999/xhtml" style="width:32px;height:32px;" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e208" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e208</title>\
<path d="M214.133 681.384q0-7.625 5.639-13.264l186.984-186.984-186.984-186.984q-5.639-5.639-5.639-13.583t5.639-13.264l78.797-78.717q5.561-5.322 13.186-5.322t13.264 5.322l187.299 186.984 186.984-186.984q5.322-5.322 13.264-5.322t13.264 5.322l78.717 78.717q5.322 5.322 5.322 13.264t-5.322 13.583l-186.665 186.984 186.665 186.665q5.322 5.639 5.322 13.424t-5.322 13.424l-78.717 78.717q-5.322 5.639-13.264 5.639t-13.583-5.639l-186.665-186.665-186.984 186.984q-5.322 5.322-13.264 5.322t-13.583-5.322l-78.717-79.114q-5.639-5.561-5.639-13.185z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e319" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e319</title>\
<path d="M147.965 861.773v-628.86q0-6.99 4.765-11.756t11.756-4.765h546.094v645.383q0 6.911-4.765 11.756t-11.756 4.765h-529.571q-6.911 0-11.756-4.765t-4.765-11.756zM280.296 183.268v-82.769q0-6.592 5.481-11.597t12.39-4.926h528.221q6.99 0 11.756 4.765t4.846 11.756v628.86q0 6.99-4.846 11.756t-11.756 4.765h-82.689v-562.615h-463.404z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-android-e028" preserveAspectRatio="xMidYMid meet">\
<title>android-e028</title>\
<path d="M982.616 408.661h-431.276v-431.276h-78.677v431.276h-431.276v78.677h431.276v431.276h78.677v-431.276h431.276v-78.677z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e004" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e004</title>\
<path d="M131.364 828.65v-77.764q0-26.451 6.832-39.875t26.292-24.307q159.181-92.061 231.704-123.515v-124.388q-33.124-24.544-33.124-74.191v-98.575q0-41.702 16.045-74.824t50.519-53.617 82.371-20.493 82.45 20.493 50.439 53.617 16.045 74.824v98.575q0 49.327-33.124 73.793v124.788q61.559 25.181 231.704 123.515 19.539 10.883 26.292 24.307t6.832 39.875v77.764q0 6.99-4.846 11.756t-11.756 4.765h-728.070q-6.674 0-11.597-4.765t-5.004-11.756z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e028" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e028</title>\
<path d="M123.103 406.312q0-63.863 25.021-121.928t67.041-100.163 100.242-66.96 122.165-25.021 121.927 25.021 100.083 66.959 67.041 100.163 25.022 121.927q0 92.061-50.36 170.143l194.607 194.607q5.004 4.607 5.004 11.597t-5.004 11.915l-70.455 70.455q-4.607 4.687-11.756 4.687t-11.756-4.687l-194.607-194.607q-77.445 50.36-169.745 50.36-63.942 0-122.165-25.022t-100.242-67.041-67.041-100.242-25.021-122.165zM223.106 406.312q0 43.687 16.999 83.404t45.833 68.39 68.39 45.673 83.244 16.999 83.165-16.999 68.39-45.673 45.833-68.39 17.077-83.404q0-43.29-17.077-83.007t-45.833-68.39-68.39-45.672-83.165-16.999-83.244 16.999-68.39 45.672-45.833 68.39-17.077 83.007z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e196" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e196</title>\
<path d="M106.58 481.138q0-55.284 14.535-107.709t40.748-96.986 63.545-81.894 81.894-63.545 97.144-40.748 107.552-14.535q82.45 0 157.513 32.091t129.474 86.343 86.343 129.474 32.091 157.513-32.091 157.513-86.343 129.474-129.474 86.343-157.513 32.091q-54.969 0-107.552-14.535t-97.144-40.748-81.894-63.545-63.545-81.894-40.748-96.985-14.535-107.709zM412.711 696.237q0 6.99 4.765 11.756t11.756 4.846h198.579q6.99 0 11.756-4.846t4.846-11.756v-66.167q0-6.592-4.846-11.597t-11.756-4.926h-49.647v-215.182q0-6.911-4.765-11.756t-11.756-4.765h-132.414q-6.911 0-11.756 4.765t-4.765 11.756v66.246q0 6.911 4.765 11.756t11.756 4.765h49.646v132.414h-49.646q-6.911 0-11.756 4.926t-4.765 11.597v66.167zM478.876 332.202q0 6.99 4.846 11.756t11.756 4.765h66.167q6.99 0 11.756-4.765t4.765-11.756v-66.167q0-6.99-4.765-11.756t-11.756-4.846h-66.167q-6.99 0-11.756 4.846t-4.846 11.756v66.167z"/>\
</symbol></defs></svg>\
                     <!--load fonticon android-e028-->\
                     <use xlink:href="#icon-android-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page608432602-layer-textinput549446873" style="position: absolute; left: 90px; top: 275px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput549446873" data-review-reference-id="textinput549446873">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page608432602-layer-textinput549446873input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page608432602-layer-textinput537805994" style="position: absolute; left: 305px; top: 275px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput537805994" data-review-reference-id="textinput537805994">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page608432602-layer-textinput537805994input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page608432602-layer-textinput238384218" style="position: absolute; left: 525px; top: 275px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput238384218" data-review-reference-id="textinput238384218">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page608432602-layer-textinput238384218input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page608432602-layer-799845888" style="position: absolute; left: 35px; top: 360px; width: 32px; height: 32px" data-stencil-type="fonticon.icon" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="799845888" data-review-reference-id="799845888">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" xmlns="http://www.w3.org/1999/xhtml" style="width:32px;height:32px;" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon android-e028-->\
                     <use xlink:href="#icon-android-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page608432602-layer-1580167289" style="position: absolute; left: 90px; top: 360px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1580167289" data-review-reference-id="1580167289">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page608432602-layer-1580167289input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page608432602-layer-1108071759" style="position: absolute; left: 305px; top: 360px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1108071759" data-review-reference-id="1108071759">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page608432602-layer-1108071759input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page608432602-layer-748597060" style="position: absolute; left: 525px; top: 360px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="748597060" data-review-reference-id="748597060">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page608432602-layer-748597060input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page608432602-layer-696074213" style="position: absolute; left: 35px; top: 440px; width: 32px; height: 32px" data-stencil-type="fonticon.icon" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="696074213" data-review-reference-id="696074213">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" xmlns="http://www.w3.org/1999/xhtml" style="width:32px;height:32px;" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon android-e028-->\
                     <use xlink:href="#icon-android-e028"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page608432602-layer-1999698528" style="position: absolute; left: 90px; top: 440px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1999698528" data-review-reference-id="1999698528">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page608432602-layer-1999698528input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page608432602-layer-1188639807" style="position: absolute; left: 305px; top: 440px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1188639807" data-review-reference-id="1188639807">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page608432602-layer-1188639807input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page608432602-layer-719136025" style="position: absolute; left: 525px; top: 440px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="719136025" data-review-reference-id="719136025">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page608432602-layer-719136025input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page608432602-layer-text784766545" style="position: absolute; left: 90px; top: 215px; width: 99px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text784766545" data-review-reference-id="text784766545">\
            <div class="stencil-wrapper" style="width: 99px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:104px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Product Name:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page608432602-layer-text550207258" style="position: absolute; left: 305px; top: 215px; width: 58px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text550207258" data-review-reference-id="text550207258">\
            <div class="stencil-wrapper" style="width: 58px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:63px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Quantity</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page608432602-layer-text86006009" style="position: absolute; left: 525px; top: 215px; width: 38px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text86006009" data-review-reference-id="text86006009">\
            <div class="stencil-wrapper" style="width: 38px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:43px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Price</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page608432602-layer-button33275904" style="position: absolute; left: 340px; top: 560px; width: 96px; height: 30px" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="button33275904" data-review-reference-id="button33275904">\
            <div class="stencil-wrapper" style="width: 96px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:96px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Add Product</button></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 96px; height: 30px"></div>\
            <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					Raven.context(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-page608432602-layer-button33275904\', \'interaction24557309\', {"button":"left","id":"action627393306","numberOfFinger":"1","type":"click"},  \
							[\
								{"delay":"0","id":"reaction72221811","options":"withoutReloadOnly","target":"page906964771","transition":"none","type":"showPage"}\
							]\
						);\
					});\
				});\
			</script></div>\
         </div>\
         <div id="__containerId__-page608432602-layer-text98045632" style="position: absolute; left: 595px; top: 90px; width: 182px; height: 37px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text98045632" data-review-reference-id="text98045632">\
            <div class="stencil-wrapper" style="width: 182px; height: 37px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:187px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12">\
                        <p><span style="font-size: 32px;">Add Product</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page608432602-layer-1275279964" style="position: absolute; left: 0px; top: 65px; width: 1366px; height: 20px" data-stencil-type="default.menu" data-interactive-element-type="default.menu" class="menu stencil mobile-interaction-potential-trigger " data-stencil-id="1275279964" data-review-reference-id="1275279964">\
            <div class="stencil-wrapper" style="width: 1366px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="yui-skin-sam  menu" style="width:1366px;height:20px;" title="">\
                  <div id="__containerId__-page608432602-layer-1275279964-menu-container"></div>\
               </div><script xmlns="http://www.w3.org/1999/xhtml" type="text/javascript">Raven.context(function () {\
			rabbit.stencils.menu.setupMenu("__containerId__-page608432602-layer-1275279964", \'[{"text":"Menu","submenu":{"id":"menu552644809-0","itemdata":[{"text":"Product List ","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page381066001"}},{"text":"Transaction list","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page497637931"}},{"text":"Process Order","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page11821914"}}]}},{"text":"Edit ","submenu":{"id":"menu552644809-1","itemdata":[{"text":"add ","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page608432602"}},{"text":"Update","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page906964771"}},{"text":"Delete","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page835478005"}}]}}]\', \'horizontal\');\
		});</script></div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page608432602"] .border-wrapper,\
         		body[data-current-page-id="page608432602"] .simulation-container {\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page608432602"] .border-wrapper,\
         		body.has-frame[data-current-page-id="page608432602"] .simulation-container {\
         			height:660px;\
         		}\
         		\
         		body[data-current-page-id="page608432602"] .svg-border-1366-660 {\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page608432602"] .border-wrapper .border-div {\
         			width:1366px;\
         			height:660px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page608432602",\
      			"name": "Update inventory(add)",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":660,\
      			"parentFolder": "",\
      			"frame": "browser",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
</div>');