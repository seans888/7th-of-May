rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__page791573617-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page791573617" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page791573617-layer-d1854e3603859237" style="position: absolute; left: 460px; top: 160px; width: 370px; height: 235px" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="d1854e3603859237" data-review-reference-id="d1854e3603859237">\
            <div class="stencil-wrapper" style="width: 370px; height: 235px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 235px; width:370px;" width="370" height="235" viewBox="0 0 370 235">\
                     <g width="370" height="235">\
                        <rect x="0" y="0" width="370" height="235" style="stroke-width:1;stroke:black;fill:white;"></rect>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page791573617-layer-d1854e14754438477" style="position: absolute; left: 460px; top: 193px; width: 370px; height: 4px" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="d1854e14754438477" data-review-reference-id="d1854e14754438477">\
            <div class="stencil-wrapper" style="width: 370px; height: 4px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:370px;" viewBox="0 0 370 4" width="370" height="4">\
                     <path d="M 0,2 L 370,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page791573617-layer-d1854e25316819056" style="position: absolute; left: 470px; top: 175px; width: 76px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="d1854e25316819056" data-review-reference-id="d1854e25316819056">\
            <div class="stencil-wrapper" style="width: 76px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:81px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Information</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page791573617-layer-d1854e40315121582" style="position: absolute; left: 790px; top: 170px; width: 35px; height: 20px" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="d1854e40315121582" data-review-reference-id="d1854e40315121582">\
            <div class="stencil-wrapper" style="width: 35px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 20px; width:35px;" width="35" height="20" viewBox="0 0 35 20">\
                     <g width="35" height="20">\
                        <rect x="0" y="0" width="35" height="20" style="stroke-width:1;stroke:black;fill:white;"></rect>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page791573617-layer-d1854e51825540057" style="position: absolute; left: 799px; top: 173px; width: 16px; height: 16px" data-stencil-type="fonticon.icon" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="d1854e51825540057" data-review-reference-id="d1854e51825540057">\
            <div class="stencil-wrapper" style="width: 16px; height: 16px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" xmlns="http://www.w3.org/1999/xhtml" style="width:16px;height:16px;" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" width="16" height="16" class="fill-black">\
                     <svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e208" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e208</title>\
<path d="M214.133 681.384q0-7.625 5.639-13.264l186.984-186.984-186.984-186.984q-5.639-5.639-5.639-13.583t5.639-13.264l78.797-78.717q5.561-5.322 13.186-5.322t13.264 5.322l187.299 186.984 186.984-186.984q5.322-5.322 13.264-5.322t13.264 5.322l78.717 78.717q5.322 5.322 5.322 13.264t-5.322 13.583l-186.665 186.984 186.665 186.665q5.322 5.639 5.322 13.424t-5.322 13.424l-78.717 78.717q-5.322 5.639-13.264 5.639t-13.583-5.639l-186.665-186.665-186.984 186.984q-5.322 5.322-13.264 5.322t-13.583-5.322l-78.717-79.114q-5.639-5.561-5.639-13.185z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e319" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e319</title>\
<path d="M147.965 861.773v-628.86q0-6.99 4.765-11.756t11.756-4.765h546.094v645.383q0 6.911-4.765 11.756t-11.756 4.765h-529.571q-6.911 0-11.756-4.765t-4.765-11.756zM280.296 183.268v-82.769q0-6.592 5.481-11.597t12.39-4.926h528.221q6.99 0 11.756 4.765t4.846 11.756v628.86q0 6.99-4.846 11.756t-11.756 4.765h-82.689v-562.615h-463.404z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-android-e028" preserveAspectRatio="xMidYMid meet">\
<title>android-e028</title>\
<path d="M982.616 408.661h-431.276v-431.276h-78.677v431.276h-431.276v78.677h431.276v431.276h78.677v-431.276h431.276v-78.677z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e004" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e004</title>\
<path d="M131.364 828.65v-77.764q0-26.451 6.832-39.875t26.292-24.307q159.181-92.061 231.704-123.515v-124.388q-33.124-24.544-33.124-74.191v-98.575q0-41.702 16.045-74.824t50.519-53.617 82.371-20.493 82.45 20.493 50.439 53.617 16.045 74.824v98.575q0 49.327-33.124 73.793v124.788q61.559 25.181 231.704 123.515 19.539 10.883 26.292 24.307t6.832 39.875v77.764q0 6.99-4.846 11.756t-11.756 4.765h-728.070q-6.674 0-11.597-4.765t-5.004-11.756z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e028" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e028</title>\
<path d="M123.103 406.312q0-63.863 25.021-121.928t67.041-100.163 100.242-66.96 122.165-25.021 121.927 25.021 100.083 66.959 67.041 100.163 25.022 121.927q0 92.061-50.36 170.143l194.607 194.607q5.004 4.607 5.004 11.597t-5.004 11.915l-70.455 70.455q-4.607 4.687-11.756 4.687t-11.756-4.687l-194.607-194.607q-77.445 50.36-169.745 50.36-63.942 0-122.165-25.022t-100.242-67.041-67.041-100.242-25.021-122.165zM223.106 406.312q0 43.687 16.999 83.404t45.833 68.39 68.39 45.673 83.244 16.999 83.165-16.999 68.39-45.673 45.833-68.39 17.077-83.404q0-43.29-17.077-83.007t-45.833-68.39-68.39-45.672-83.165-16.999-83.244 16.999-68.39 45.672-45.833 68.39-17.077 83.007z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e196" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e196</title>\
<path d="M106.58 481.138q0-55.284 14.535-107.709t40.748-96.986 63.545-81.894 81.894-63.545 97.144-40.748 107.552-14.535q82.45 0 157.513 32.091t129.474 86.343 86.343 129.474 32.091 157.513-32.091 157.513-86.343 129.474-129.474 86.343-157.513 32.091q-54.969 0-107.552-14.535t-97.144-40.748-81.894-63.545-63.545-81.894-40.748-96.985-14.535-107.709zM412.711 696.237q0 6.99 4.765 11.756t11.756 4.846h198.579q6.99 0 11.756-4.846t4.846-11.756v-66.167q0-6.592-4.846-11.597t-11.756-4.926h-49.647v-215.182q0-6.911-4.765-11.756t-11.756-4.765h-132.414q-6.911 0-11.756 4.765t-4.765 11.756v66.246q0 6.911 4.765 11.756t11.756 4.765h49.646v132.414h-49.646q-6.911 0-11.756 4.926t-4.765 11.597v66.167zM478.876 332.202q0 6.99 4.846 11.756t11.756 4.765h66.167q6.99 0 11.756-4.765t4.765-11.756v-66.167q0-6.99-4.765-11.756t-11.756-4.846h-66.167q-6.99 0-11.756 4.846t-4.846 11.756v66.167z"/>\
</symbol></defs></svg>\
                     <!--load fonticon glyph-e208-->\
                     <use xlink:href="#icon-glyph-e208"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page791573617-layer-d1854e62689724135" style="position: absolute; left: 475px; top: 210px; width: 32px; height: 32px" data-stencil-type="fonticon.icon" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="d1854e62689724135" data-review-reference-id="d1854e62689724135">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" xmlns="http://www.w3.org/1999/xhtml" style="width:32px;height:32px;" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e196-->\
                     <use xlink:href="#icon-glyph-e196"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page791573617-layer-d1854e73668169074" style="position: absolute; left: 535px; top: 220px; width: 204px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="d1854e73668169074" data-review-reference-id="d1854e73668169074">\
            <div class="stencil-wrapper" style="width: 204px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:209px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">This is an information message.</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page791573617-layer-d1854e88930591034" style="position: absolute; left: 725px; top: 360px; width: 90px; height: 30px" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="d1854e88930591034" data-review-reference-id="d1854e88930591034">\
            <div class="stencil-wrapper" style="width: 90px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:90px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">SHOW</button></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 90px; height: 30px"></div>\
            <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					Raven.context(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-page791573617-layer-d1854e88930591034\', \'interaction684519372\', {"button":"left","id":"action140200034","numberOfFinger":"1","type":"click"},  \
							[\
								{"delay":"0","id":"reaction682841921","options":"withoutReloadOnly","target":"page867492436","transition":"none","type":"showPage"}\
							]\
						);\
					});\
				});\
			</script></div>\
         </div>\
         <div id="__containerId__-page791573617-layer-d1854e105578499258" style="position: absolute; left: 535px; top: 265px; width: 260px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="d1854e105578499258" data-review-reference-id="d1854e105578499258">\
            <div class="stencil-wrapper" style="width: 260px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;"><span style="font-size: 11px;">THERE ARE PRODUCTS NEEDED TO REPLENISH<br /></span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page791573617-layer-d1854e120669873117" style="position: absolute; left: 460px; top: 348px; width: 370px; height: 4px" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="d1854e120669873117" data-review-reference-id="d1854e120669873117">\
            <div class="stencil-wrapper" style="width: 370px; height: 4px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:370px;" viewBox="0 0 370 4" width="370" height="4">\
                     <path d="M 0,2 L 370,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page791573617-layer-d1854e131719954451" style="position: absolute; left: 765px; top: 170px; width: 25px; height: 20px" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="d1854e131719954451" data-review-reference-id="d1854e131719954451">\
            <div class="stencil-wrapper" style="width: 25px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 20px; width:25px;" width="25" height="20" viewBox="0 0 25 20">\
                     <g width="25" height="20">\
                        <rect x="0" y="0" width="25" height="20" style="stroke-width:1;stroke:black;fill:white;"></rect>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page791573617-layer-d1854e143946020767" style="position: absolute; left: 740px; top: 170px; width: 25px; height: 20px" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="d1854e143946020767" data-review-reference-id="d1854e143946020767">\
            <div class="stencil-wrapper" style="width: 25px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 20px; width:25px;" width="25" height="20" viewBox="0 0 25 20">\
                     <g width="25" height="20">\
                        <rect x="0" y="0" width="25" height="20" style="stroke-width:1;stroke:black;fill:white;"></rect>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page791573617-layer-d1854e15474283467" style="position: absolute; left: 770px; top: 173px; width: 16px; height: 16px" data-stencil-type="fonticon.icon" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="d1854e15474283467" data-review-reference-id="d1854e15474283467">\
            <div class="stencil-wrapper" style="width: 16px; height: 16px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" xmlns="http://www.w3.org/1999/xhtml" style="width:16px;height:16px;" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" width="16" height="16" class="fill-black">\
                     <!--print symbols here-->\
                     <!--load fonticon glyph-e319-->\
                     <use xlink:href="#icon-glyph-e319"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page791573617-layer-d1854e165759275697" style="position: absolute; left: 747px; top: 183px; width: 10px; height: 4px" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="d1854e165759275697" data-review-reference-id="d1854e165759275697">\
            <div class="stencil-wrapper" style="width: 10px; height: 4px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:10px;" viewBox="0 0 10 4" width="10" height="4">\
                     <path d="M 0,2 L 10,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page791573617"] .border-wrapper,\
         		body[data-current-page-id="page791573617"] .simulation-container {\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page791573617"] .border-wrapper,\
         		body.has-frame[data-current-page-id="page791573617"] .simulation-container {\
         			height:660px;\
         		}\
         		\
         		body[data-current-page-id="page791573617"] .svg-border-1366-660 {\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page791573617"] .border-wrapper .border-div {\
         			width:1366px;\
         			height:660px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page791573617",\
      			"name": "Notification replenish",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":660,\
      			"parentFolder": "",\
      			"frame": "browser",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
</div>');