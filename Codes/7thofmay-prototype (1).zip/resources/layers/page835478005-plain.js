rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__page835478005-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page835478005" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page835478005-layer-text586665741" style="position: absolute; left: 555px; top: 85px; width: 218px; height: 37px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text586665741" data-review-reference-id="text586665741">\
            <div class="stencil-wrapper" style="width: 218px; height: 37px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:223px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12">\
                        <p><span style="font-size: 32px;">Delete Product</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page835478005-layer-combobox865731823" style="position: absolute; left: 340px; top: 200px; width: 640px; height: 355px" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox865731823" data-review-reference-id="combobox865731823">\
            <div class="stencil-wrapper" style="width: 640px; height: 355px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page835478005-layer-combobox865731823select" style="width:640px;height:355px;" title="">\
                     <option title="">First entry</option>\
                     <option title="">Second entry</option>\
                     <option title="">Third entry</option></select></div>\
            </div>\
         </div>\
         <div id="__containerId__-page835478005-layer-button590821410" style="position: absolute; left: 625px; top: 620px; width: 65px; height: 30px" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button stencil mobile-interaction-potential-trigger " data-stencil-id="button590821410" data-review-reference-id="button590821410">\
            <div class="stencil-wrapper" style="width: 65px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:65px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Delete</button></div>\
            </div>\
         </div>\
         <div id="__containerId__-page835478005-layer-1586758236" style="position: absolute; left: 0px; top: 55px; width: 1366px; height: 20px" data-stencil-type="default.menu" data-interactive-element-type="default.menu" class="menu stencil mobile-interaction-potential-trigger " data-stencil-id="1586758236" data-review-reference-id="1586758236">\
            <div class="stencil-wrapper" style="width: 1366px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="yui-skin-sam  menu" style="width:1366px;height:20px;" title="">\
                  <div id="__containerId__-page835478005-layer-1586758236-menu-container"></div>\
               </div><script xmlns="http://www.w3.org/1999/xhtml" type="text/javascript">Raven.context(function () {\
			rabbit.stencils.menu.setupMenu("__containerId__-page835478005-layer-1586758236", \'[{"text":"Menu","submenu":{"id":"menu552644809-0","itemdata":[{"text":"Product List ","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page381066001"}},{"text":"Transaction list","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page497637931"}},{"text":"Process Order","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page11821914"}}]}},{"text":"Edit ","submenu":{"id":"menu552644809-1","itemdata":[{"text":"add ","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page608432602"}},{"text":"Update","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page906964771"}},{"text":"Delete","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page835478005"}}]}}]\', \'horizontal\');\
		});</script></div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page835478005"] .border-wrapper,\
         		body[data-current-page-id="page835478005"] .simulation-container {\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page835478005"] .border-wrapper,\
         		body.has-frame[data-current-page-id="page835478005"] .simulation-container {\
         			height:660px;\
         		}\
         		\
         		body[data-current-page-id="page835478005"] .svg-border-1366-660 {\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page835478005"] .border-wrapper .border-div {\
         			width:1366px;\
         			height:660px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page835478005",\
      			"name": "Update Inventory(Delete)",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":660,\
      			"parentFolder": "",\
      			"frame": "browser",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
</div>');