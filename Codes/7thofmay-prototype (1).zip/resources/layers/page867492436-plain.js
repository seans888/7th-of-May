rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__page867492436-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page867492436" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page867492436-layer-iphoneListBackground53776651" style="position: absolute; left: 15px; top: 155px; width: 195px; height: 340px" data-stencil-type="static.iphoneListBackground" data-interactive-element-type="static.iphoneListBackground" class="iphoneListBackground stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneListBackground53776651" data-review-reference-id="iphoneListBackground53776651">\
            <div class="stencil-wrapper" style="width: 195px; height: 340px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="height: 340px; width:195px;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" width="195" height="340" viewBox="0 0 195 340">\
                     <rect x="1" y="1" width="193" rx="10" height="338" style="stroke-width:1;fill:white;;stroke:black;"></rect>\
                     <line x1="1" y1="40" x2="193" y2="40" style="stroke-width:1;stroke:black;"></line>\
                     <line x1="1" y1="80" x2="193" y2="80" style="stroke-width:1;stroke:black;"></line>\
                     <line x1="1" y1="120" x2="193" y2="120" style="stroke-width:1;stroke:black;"></line>\
                     <line x1="1" y1="160" x2="193" y2="160" style="stroke-width:1;stroke:black;"></line>\
                     <line x1="1" y1="200" x2="193" y2="200" style="stroke-width:1;stroke:black;"></line>\
                     <line x1="1" y1="240" x2="193" y2="240" style="stroke-width:1;stroke:black;"></line>\
                     <line x1="1" y1="280" x2="193" y2="280" style="stroke-width:1;stroke:black;"></line>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page867492436-layer-text182117476" style="position: absolute; left: 20px; top: 125px; width: 250px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text182117476" data-review-reference-id="text182117476">\
            <div class="stencil-wrapper" style="width: 250px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:255px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">PRODUCT NEEDS REPLENISHMENT</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page867492436-layer-button757146083" style="position: absolute; left: 75px; top: 540px; width: 60px; height: 30px" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="button757146083" data-review-reference-id="button757146083">\
            <div class="stencil-wrapper" style="width: 60px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:60px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">next</button></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 60px; height: 30px"></div>\
            <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					Raven.context(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-page867492436-layer-button757146083\', \'interaction164368785\', {"button":"left","id":"action692393772","numberOfFinger":"1","type":"click"},  \
							[\
								{"delay":"0","id":"reaction75044907","options":"withoutReloadOnly","target":"page381066001","transition":"none","type":"showPage"}\
							]\
						);\
					});\
				});\
			</script></div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page867492436"] .border-wrapper,\
         		body[data-current-page-id="page867492436"] .simulation-container {\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page867492436"] .border-wrapper,\
         		body.has-frame[data-current-page-id="page867492436"] .simulation-container {\
         			height:660px;\
         		}\
         		\
         		body[data-current-page-id="page867492436"] .svg-border-1366-660 {\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page867492436"] .border-wrapper .border-div {\
         			width:1366px;\
         			height:660px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page867492436",\
      			"name": "Product replenish list",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":660,\
      			"parentFolder": "",\
      			"frame": "browser",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
</div>');