rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__page11821914-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page11821914" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page11821914-layer-text245950489" style="position: absolute; left: 45px; top: 65px; width: 47px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text245950489" data-review-reference-id="text245950489">\
            <div class="stencil-wrapper" style="width: 47px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:52px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Name:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-textinput549353876" style="position: absolute; left: 160px; top: 60px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput549353876" data-review-reference-id="textinput549353876">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page11821914-layer-textinput549353876input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-text350703243" style="position: absolute; left: 45px; top: 120px; width: 70px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text350703243" data-review-reference-id="text350703243">\
            <div class="stencil-wrapper" style="width: 70px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:75px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Contact #:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-textinput816077589" style="position: absolute; left: 160px; top: 115px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput816077589" data-review-reference-id="textinput816077589">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page11821914-layer-textinput816077589input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-text893050216" style="position: absolute; left: 45px; top: 185px; width: 61px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text893050216" data-review-reference-id="text893050216">\
            <div class="stencil-wrapper" style="width: 61px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:66px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Address:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-textinput211210266" style="position: absolute; left: 160px; top: 175px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput211210266" data-review-reference-id="textinput211210266">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page11821914-layer-textinput211210266input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-combobox967396779" style="position: absolute; left: 160px; top: 230px; width: 150px; height: 30px" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox967396779" data-review-reference-id="combobox967396779">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page11821914-layer-combobox967396779select" style="width:150px;height:30px;" title="">\
                     <option title="">First entry</option>\
                     <option title="">Second entry</option>\
                     <option title="">Third entry</option></select></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-1470477594" style="position: absolute; left: 40px; top: 235px; width: 37px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1470477594" data-review-reference-id="1470477594">\
            <div class="stencil-wrapper" style="width: 37px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:42px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Item:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-1150523023" style="position: absolute; left: 465px; top: 230px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1150523023" data-review-reference-id="1150523023">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page11821914-layer-1150523023input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-1372556046" style="position: absolute; left: 375px; top: 235px; width: 32px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1372556046" data-review-reference-id="1372556046">\
            <div class="stencil-wrapper" style="width: 32px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:37px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Qty:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-clickArea411811619" style="position: absolute; left: 775px; top: 225px; width: 150px; height: 35px" data-stencil-type="default.clickArea" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="clickArea411811619" data-review-reference-id="clickArea411811619">\
            <div class="stencil-wrapper" style="width: 150px; height: 35px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" xmlns="http://www.w3.org/1999/xhtml" title="" style="height: 35px; width:150px; cursor:pointer;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" data-stencil="ClickArea" overflow="hidden" style="height: 35px;width:150px;" width="150" height="35" viewBox="0 0 150 35"><a>\
                        <rect x="0" y="0" width="150" height="35" style="stroke:none;fill:white;opacity:0.01;"></rect></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-1664867980" style="position: absolute; left: 690px; top: 235px; width: 42px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1664867980" data-review-reference-id="1664867980">\
            <div class="stencil-wrapper" style="width: 42px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:47px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Price:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-1236204277" style="position: absolute; left: 160px; top: 305px; width: 150px; height: 30px" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="1236204277" data-review-reference-id="1236204277">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page11821914-layer-1236204277select" style="width:150px;height:30px;" title="">\
                     <option title="">First entry</option>\
                     <option title="">Second entry</option>\
                     <option title="">Third entry</option></select></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-776888205" style="position: absolute; left: 40px; top: 310px; width: 37px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="776888205" data-review-reference-id="776888205">\
            <div class="stencil-wrapper" style="width: 37px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:42px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Item:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-287187980" style="position: absolute; left: 465px; top: 305px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="287187980" data-review-reference-id="287187980">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page11821914-layer-287187980input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-742890644" style="position: absolute; left: 375px; top: 310px; width: 32px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="742890644" data-review-reference-id="742890644">\
            <div class="stencil-wrapper" style="width: 32px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:37px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Qty:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-1752244018" style="position: absolute; left: 775px; top: 300px; width: 150px; height: 35px" data-stencil-type="default.clickArea" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1752244018" data-review-reference-id="1752244018">\
            <div class="stencil-wrapper" style="width: 150px; height: 35px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" xmlns="http://www.w3.org/1999/xhtml" title="" style="height: 35px; width:150px; cursor:pointer;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" data-stencil="ClickArea" overflow="hidden" style="height: 35px;width:150px;" width="150" height="35" viewBox="0 0 150 35"><a>\
                        <rect x="0" y="0" width="150" height="35" style="stroke:none;fill:white;opacity:0.01;"></rect></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-555563145" style="position: absolute; left: 690px; top: 310px; width: 42px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="555563145" data-review-reference-id="555563145">\
            <div class="stencil-wrapper" style="width: 42px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:47px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Price:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-text330596375" style="position: absolute; left: 640px; top: 20px; width: 212px; height: 37px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text330596375" data-review-reference-id="text330596375">\
            <div class="stencil-wrapper" style="width: 212px; height: 37px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:217px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12">\
                        <p><span style="font-size: 32px;">Process Order</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-512986843" style="position: absolute; left: 160px; top: 375px; width: 150px; height: 30px" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="512986843" data-review-reference-id="512986843">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page11821914-layer-512986843select" style="width:150px;height:30px;" title="">\
                     <option title="">First entry</option>\
                     <option title="">Second entry</option>\
                     <option title="">Third entry</option></select></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-974700093" style="position: absolute; left: 40px; top: 380px; width: 37px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="974700093" data-review-reference-id="974700093">\
            <div class="stencil-wrapper" style="width: 37px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:42px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Item:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-322567860" style="position: absolute; left: 465px; top: 375px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="322567860" data-review-reference-id="322567860">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page11821914-layer-322567860input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-142309342" style="position: absolute; left: 375px; top: 380px; width: 32px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="142309342" data-review-reference-id="142309342">\
            <div class="stencil-wrapper" style="width: 32px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:37px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Qty:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-1688356986" style="position: absolute; left: 775px; top: 370px; width: 150px; height: 35px" data-stencil-type="default.clickArea" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1688356986" data-review-reference-id="1688356986">\
            <div class="stencil-wrapper" style="width: 150px; height: 35px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" xmlns="http://www.w3.org/1999/xhtml" title="" style="height: 35px; width:150px; cursor:pointer;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" data-stencil="ClickArea" overflow="hidden" style="height: 35px;width:150px;" width="150" height="35" viewBox="0 0 150 35"><a>\
                        <rect x="0" y="0" width="150" height="35" style="stroke:none;fill:white;opacity:0.01;"></rect></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-984076364" style="position: absolute; left: 690px; top: 380px; width: 42px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="984076364" data-review-reference-id="984076364">\
            <div class="stencil-wrapper" style="width: 42px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:47px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Price:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-1586233877" style="position: absolute; left: 160px; top: 450px; width: 150px; height: 30px" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="1586233877" data-review-reference-id="1586233877">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page11821914-layer-1586233877select" style="width:150px;height:30px;" title="">\
                     <option title="">First entry</option>\
                     <option title="">Second entry</option>\
                     <option title="">Third entry</option></select></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-1911214018" style="position: absolute; left: 40px; top: 455px; width: 37px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1911214018" data-review-reference-id="1911214018">\
            <div class="stencil-wrapper" style="width: 37px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:42px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Item:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-1725096065" style="position: absolute; left: 465px; top: 450px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1725096065" data-review-reference-id="1725096065">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page11821914-layer-1725096065input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-189748403" style="position: absolute; left: 375px; top: 455px; width: 32px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="189748403" data-review-reference-id="189748403">\
            <div class="stencil-wrapper" style="width: 32px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:37px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Qty:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-1860177332" style="position: absolute; left: 775px; top: 445px; width: 150px; height: 35px" data-stencil-type="default.clickArea" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1860177332" data-review-reference-id="1860177332">\
            <div class="stencil-wrapper" style="width: 150px; height: 35px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" xmlns="http://www.w3.org/1999/xhtml" title="" style="height: 35px; width:150px; cursor:pointer;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" data-stencil="ClickArea" overflow="hidden" style="height: 35px;width:150px;" width="150" height="35" viewBox="0 0 150 35"><a>\
                        <rect x="0" y="0" width="150" height="35" style="stroke:none;fill:white;opacity:0.01;"></rect></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-914983718" style="position: absolute; left: 690px; top: 455px; width: 42px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="914983718" data-review-reference-id="914983718">\
            <div class="stencil-wrapper" style="width: 42px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:47px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Price:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-text882189254" style="position: absolute; left: 445px; top: 520px; width: 55px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text882189254" data-review-reference-id="text882189254">\
            <div class="stencil-wrapper" style="width: 55px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:60px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Change</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-146908857" style="position: absolute; left: 35px; top: 570px; width: 86px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="146908857" data-review-reference-id="146908857">\
            <div class="stencil-wrapper" style="width: 86px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:91px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Amount Paid</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-2030643728" style="position: absolute; left: 40px; top: 530px; width: 96px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2030643728" data-review-reference-id="2030643728">\
            <div class="stencil-wrapper" style="width: 96px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:101px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Payment Type</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-combobox347993408" style="position: absolute; left: 160px; top: 525px; width: 150px; height: 30px" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox347993408" data-review-reference-id="combobox347993408">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page11821914-layer-combobox347993408select" style="width:150px;height:30px;" title="">\
                     <option title="">Cash</option>\
                     <option title="">Credit Card</option>\
                     <option title="">Cheque</option></select></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-390686712" style="position: absolute; left: 160px; top: 560px; width: 150px; height: 35px" data-stencil-type="default.clickArea" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="390686712" data-review-reference-id="390686712">\
            <div class="stencil-wrapper" style="width: 150px; height: 35px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" xmlns="http://www.w3.org/1999/xhtml" title="" style="height: 35px; width:150px; cursor:pointer;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" data-stencil="ClickArea" overflow="hidden" style="height: 35px;width:150px;" width="150" height="35" viewBox="0 0 150 35"><a>\
                        <rect x="0" y="0" width="150" height="35" style="stroke:none;fill:white;opacity:0.01;"></rect></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-1338541509" style="position: absolute; left: 565px; top: 515px; width: 150px; height: 35px" data-stencil-type="default.clickArea" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="1338541509" data-review-reference-id="1338541509">\
            <div class="stencil-wrapper" style="width: 150px; height: 35px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" xmlns="http://www.w3.org/1999/xhtml" title="" style="height: 35px; width:150px; cursor:pointer;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" data-stencil="ClickArea" overflow="hidden" style="height: 35px;width:150px;" width="150" height="35" viewBox="0 0 150 35"><a>\
                        <rect x="0" y="0" width="150" height="35" style="stroke:none;fill:white;opacity:0.01;"></rect></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-text461384654" style="position: absolute; left: 190px; top: 570px; width: 86px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text461384654" data-review-reference-id="text461384654">\
            <div class="stencil-wrapper" style="width: 86px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:91px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Amount Paid</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-text480145289" style="position: absolute; left: 610px; top: 525px; width: 55px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text480145289" data-review-reference-id="text480145289">\
            <div class="stencil-wrapper" style="width: 55px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:60px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Change</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-332951155" style="position: absolute; left: 40px; top: 605px; width: 36px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="332951155" data-review-reference-id="332951155">\
            <div class="stencil-wrapper" style="width: 36px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:41px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Total</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-814214833" style="position: absolute; left: 160px; top: 600px; width: 150px; height: 35px" data-stencil-type="default.clickArea" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="814214833" data-review-reference-id="814214833">\
            <div class="stencil-wrapper" style="width: 150px; height: 35px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" xmlns="http://www.w3.org/1999/xhtml" title="" style="height: 35px; width:150px; cursor:pointer;">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" data-stencil="ClickArea" overflow="hidden" style="height: 35px;width:150px;" width="150" height="35" viewBox="0 0 150 35"><a>\
                        <rect x="0" y="0" width="150" height="35" style="stroke:none;fill:white;opacity:0.01;"></rect></a></svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-737226603" style="position: absolute; left: 205px; top: 610px; width: 36px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="737226603" data-review-reference-id="737226603">\
            <div class="stencil-wrapper" style="width: 36px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:41px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Total</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page11821914-layer-button918044343" style="position: absolute; left: 620px; top: 600px; width: 67px; height: 30px" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="button918044343" data-review-reference-id="button918044343">\
            <div class="stencil-wrapper" style="width: 67px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:67px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Submit</button></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 67px; height: 30px"></div>\
            <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					Raven.context(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-page11821914-layer-button918044343\', \'interaction40385256\', {"button":"left","id":"action495363098","numberOfFinger":"1","type":"click"},  \
							[\
								{"delay":"0","id":"reaction858322215","options":"withoutReloadOnly","target":"page768807986","transition":"none","type":"showPage"}\
							]\
						);\
					});\
				});\
			</script></div>\
         </div>\
         <div id="__containerId__-page11821914-layer-button815183900" style="position: absolute; left: 530px; top: 600px; width: 62px; height: 30px" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="button815183900" data-review-reference-id="button815183900">\
            <div class="stencil-wrapper" style="width: 62px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:62px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Home</button></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 62px; height: 30px"></div>\
            <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					Raven.context(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-page11821914-layer-button815183900\', \'interaction536260425\', {"button":"left","id":"action840552437","numberOfFinger":"1","type":"click"},  \
							[\
								{"delay":"0","id":"reaction602735896","options":"withoutReloadOnly","target":"page871842889","transition":"none","type":"showPage"}\
							]\
						);\
					});\
				});\
			</script></div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page11821914"] .border-wrapper,\
         		body[data-current-page-id="page11821914"] .simulation-container {\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page11821914"] .border-wrapper,\
         		body.has-frame[data-current-page-id="page11821914"] .simulation-container {\
         			height:660px;\
         		}\
         		\
         		body[data-current-page-id="page11821914"] .svg-border-1366-660 {\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page11821914"] .border-wrapper .border-div {\
         			width:1366px;\
         			height:660px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page11821914",\
      			"name": "Process Order",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":660,\
      			"parentFolder": "",\
      			"frame": "browser",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
</div>');