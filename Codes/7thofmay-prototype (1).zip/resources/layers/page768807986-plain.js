rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__page768807986-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page768807986" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page768807986-layer-rect688467973" style="position: absolute; left: 375px; top: 0px; width: 450px; height: 585px" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="rect688467973" data-review-reference-id="rect688467973">\
            <div class="stencil-wrapper" style="width: 450px; height: 585px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 585px; width:450px;" width="450" height="585" viewBox="0 0 450 585">\
                     <g width="450" height="585">\
                        <rect x="0" y="0" width="450" height="585" style="stroke-width:1;stroke:black;fill:white;"></rect>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page768807986-layer-text214438082" style="position: absolute; left: 405px; top: 20px; width: 388px; height: 37px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text214438082" data-review-reference-id="text214438082">\
            <div class="stencil-wrapper" style="width: 388px; height: 37px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:393px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12">\
                        <p><span style="font-size: 32px;">7th of May Hardware Store</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page768807986-layer-text764090449" style="position: absolute; left: 525px; top: 70px; width: 134px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text764090449" data-review-reference-id="text764090449">\
            <div class="stencil-wrapper" style="width: 134px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:139px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Official Receipt(O.R)</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page768807986-layer-151403516" style="position: absolute; left: 400px; top: 310px; width: 90px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="151403516" data-review-reference-id="151403516">\
            <div class="stencil-wrapper" style="width: 90px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:95px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Amount Paid:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page768807986-layer-698166572" style="position: absolute; left: 400px; top: 275px; width: 99px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="698166572" data-review-reference-id="698166572">\
            <div class="stencil-wrapper" style="width: 99px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:104px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Payment Type:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page768807986-layer-94142803" style="position: absolute; left: 400px; top: 240px; width: 39px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="94142803" data-review-reference-id="94142803">\
            <div class="stencil-wrapper" style="width: 39px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:44px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Total:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page768807986-layer-text920789733" style="position: absolute; left: 400px; top: 130px; width: 44px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text920789733" data-review-reference-id="text920789733">\
            <div class="stencil-wrapper" style="width: 44px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:49px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Items:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page768807986-layer-text542327328" style="position: absolute; left: 400px; top: 345px; width: 59px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text542327328" data-review-reference-id="text542327328">\
            <div class="stencil-wrapper" style="width: 59px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:64px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Change:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page768807986-layer-arrow371226457" style="position: absolute; left: 690px; top: 375px; width: 101px; height: 4px" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow371226457" data-review-reference-id="arrow371226457">\
            <div class="stencil-wrapper" style="width: 101px; height: 4px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:101px;" viewBox="0 0 101 4" width="101" height="4">\
                     <path d="M 0,2 L 101,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page768807986-layer-402945663" style="position: absolute; left: 690px; top: 370px; width: 101px; height: 4px" data-stencil-type="static.line" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="402945663" data-review-reference-id="402945663">\
            <div class="stencil-wrapper" style="width: 101px; height: 4px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg style="position: absolute; left: 0px; top: 0px; height: 4px;width:101px;" viewBox="0 0 101 4" width="101" height="4">\
                     <path d="M 0,2 L 101,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></path>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page768807986-layer-740061215" style="position: absolute; left: 400px; top: 380px; width: 39px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="740061215" data-review-reference-id="740061215">\
            <div class="stencil-wrapper" style="width: 39px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:44px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Total:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page768807986-layer-button451978404" style="position: absolute; left: 575px; top: 605px; width: 60px; height: 30px" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="button451978404" data-review-reference-id="button451978404">\
            <div class="stencil-wrapper" style="width: 60px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:60px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Print</button></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 60px; height: 30px"></div>\
            <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					Raven.context(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-page768807986-layer-button451978404\', \'interaction558226536\', {"button":"left","id":"action983672394","numberOfFinger":"1","type":"click"},  \
							[\
								{"delay":"0","id":"reaction341099633","options":"withoutReloadOnly","target":"page497637931","transition":"none","type":"showPage"}\
							]\
						);\
					});\
				});\
			</script></div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page768807986"] .border-wrapper,\
         		body[data-current-page-id="page768807986"] .simulation-container {\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page768807986"] .border-wrapper,\
         		body.has-frame[data-current-page-id="page768807986"] .simulation-container {\
         			height:660px;\
         		}\
         		\
         		body[data-current-page-id="page768807986"] .svg-border-1366-660 {\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page768807986"] .border-wrapper .border-div {\
         			width:1366px;\
         			height:660px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page768807986",\
      			"name": "Print O.R",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":660,\
      			"parentFolder": "",\
      			"frame": "browser",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
</div>');