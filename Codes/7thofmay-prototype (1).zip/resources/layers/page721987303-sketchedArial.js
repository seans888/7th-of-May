rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__page721987303-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page721987303" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page721987303-layer-d1990e3781734488" style="position: absolute; left: 510px; top: 85px; width: 360px; height: 370px" data-stencil-type="static.rect" data-interactive-element-type="static.rect" class="rect stencil mobile-interaction-potential-trigger " data-stencil-id="d1990e3781734488" data-review-reference-id="d1990e3781734488">\
            <div class="stencil-wrapper" style="width: 360px; height: 370px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" overflow="hidden" style="height: 370px; width:360px;" width="360" height="370" viewBox="0 0 360 370">\
                     <g width="360" height="370">\
                        <rect x="0" y="0" width="360" height="370" style="stroke-width:1;stroke:black;fill:white;"></rect>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page721987303-layer-d1990e14906722169" style="position: absolute; left: 650px; top: 125px; width: 80px; height: 60px" data-stencil-type="default.image" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="d1990e14906722169" data-review-reference-id="d1990e14906722169">\
            <div class="stencil-wrapper" style="width: 80px; height: 60px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg class="image-cropper" style="height: 60px;width:80px;" width="80" height="60" viewBox="0 0 80 60">\
                     <g width="80" height="60">\
                        <rect x="0" y="0" width="80" height="60" style="stroke:black; stroke-width:1;fill:white;"></rect>\
                        <line x1="0" y1="0" x2="80" y2="60" style="stroke:black; stroke-width:0.5;"></line>\
                        <line x1="0" y1="60" x2="80" y2="0" style="stroke:black; stroke-width:0.5;"></line>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page721987303-layer-d1990e29271805840" style="position: absolute; left: 560px; top: 225px; width: 260px; height: 40px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="d1990e29271805840" data-review-reference-id="d1990e29271805840">\
            <div class="stencil-wrapper" style="width: 260px; height: 40px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><textarea id="__containerId__-page721987303-layer-d1990e29271805840input" rows="" cols="" style="width:258px;height:36px;padding: 0px;border-width:1px;">Username</textarea></div>\
            </div>\
         </div>\
         <div id="__containerId__-page721987303-layer-d1990e4477870341" style="position: absolute; left: 560px; top: 290px; width: 260px; height: 40px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="d1990e4477870341" data-review-reference-id="d1990e4477870341">\
            <div class="stencil-wrapper" style="width: 260px; height: 40px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><textarea id="__containerId__-page721987303-layer-d1990e4477870341input" rows="" cols="" style="width:258px;height:36px;padding: 0px;border-width:1px;">********</textarea></div>\
            </div>\
         </div>\
         <div id="__containerId__-page721987303-layer-d1990e59911691849" style="position: absolute; left: 600px; top: 370px; width: 180px; height: 40px" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="d1990e59911691849" data-review-reference-id="d1990e59911691849">\
            <div class="stencil-wrapper" style="width: 180px; height: 40px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:180px;height:40px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Login</button></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 180px; height: 40px"></div>\
            <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					Raven.context(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-page721987303-layer-d1990e59911691849\', \'interaction413558898\', {"button":"left","id":"action236984924","numberOfFinger":"1","type":"click"},  \
							[\
								{"delay":"0","id":"reaction457411096","options":"withoutReloadOnly","target":"page871842889","transition":"none","type":"showPage"}\
							]\
						);\
					});\
				});\
			</script></div>\
         </div>\
         <div id="__containerId__-page721987303-layer-icon370282418" style="position: absolute; left: 660px; top: 130px; width: 64px; height: 64px" data-stencil-type="fonticon.icon" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon370282418" data-review-reference-id="icon370282418">\
            <div class="stencil-wrapper" style="width: 64px; height: 64px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" xmlns="http://www.w3.org/1999/xhtml" style="width:64px;height:64px;" title="">\
                  <svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" width="64" height="64" class="fill-black">\
                     <svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e208" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e208</title>\
<path d="M214.133 681.384q0-7.625 5.639-13.264l186.984-186.984-186.984-186.984q-5.639-5.639-5.639-13.583t5.639-13.264l78.797-78.717q5.561-5.322 13.186-5.322t13.264 5.322l187.299 186.984 186.984-186.984q5.322-5.322 13.264-5.322t13.264 5.322l78.717 78.717q5.322 5.322 5.322 13.264t-5.322 13.583l-186.665 186.984 186.665 186.665q5.322 5.639 5.322 13.424t-5.322 13.424l-78.717 78.717q-5.322 5.639-13.264 5.639t-13.583-5.639l-186.665-186.665-186.984 186.984q-5.322 5.322-13.264 5.322t-13.583-5.322l-78.717-79.114q-5.639-5.561-5.639-13.185z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e319" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e319</title>\
<path d="M147.965 861.773v-628.86q0-6.99 4.765-11.756t11.756-4.765h546.094v645.383q0 6.911-4.765 11.756t-11.756 4.765h-529.571q-6.911 0-11.756-4.765t-4.765-11.756zM280.296 183.268v-82.769q0-6.592 5.481-11.597t12.39-4.926h528.221q6.99 0 11.756 4.765t4.846 11.756v628.86q0 6.99-4.846 11.756t-11.756 4.765h-82.689v-562.615h-463.404z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-android-e028" preserveAspectRatio="xMidYMid meet">\
<title>android-e028</title>\
<path d="M982.616 408.661h-431.276v-431.276h-78.677v431.276h-431.276v78.677h431.276v431.276h78.677v-431.276h431.276v-78.677z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e004" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e004</title>\
<path d="M131.364 828.65v-77.764q0-26.451 6.832-39.875t26.292-24.307q159.181-92.061 231.704-123.515v-124.388q-33.124-24.544-33.124-74.191v-98.575q0-41.702 16.045-74.824t50.519-53.617 82.371-20.493 82.45 20.493 50.439 53.617 16.045 74.824v98.575q0 49.327-33.124 73.793v124.788q61.559 25.181 231.704 123.515 19.539 10.883 26.292 24.307t6.832 39.875v77.764q0 6.99-4.846 11.756t-11.756 4.765h-728.070q-6.674 0-11.597-4.765t-5.004-11.756z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e028" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e028</title>\
<path d="M123.103 406.312q0-63.863 25.021-121.928t67.041-100.163 100.242-66.96 122.165-25.021 121.927 25.021 100.083 66.959 67.041 100.163 25.022 121.927q0 92.061-50.36 170.143l194.607 194.607q5.004 4.607 5.004 11.597t-5.004 11.915l-70.455 70.455q-4.607 4.687-11.756 4.687t-11.756-4.687l-194.607-194.607q-77.445 50.36-169.745 50.36-63.942 0-122.165-25.022t-100.242-67.041-67.041-100.242-25.021-122.165zM223.106 406.312q0 43.687 16.999 83.404t45.833 68.39 68.39 45.673 83.244 16.999 83.165-16.999 68.39-45.673 45.833-68.39 17.077-83.404q0-43.29-17.077-83.007t-45.833-68.39-68.39-45.672-83.165-16.999-83.244 16.999-68.39 45.672-45.833 68.39-17.077 83.007z"/>\
</symbol><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-e196" preserveAspectRatio="xMidYMid meet">\
<title>glyph-e196</title>\
<path d="M106.58 481.138q0-55.284 14.535-107.709t40.748-96.986 63.545-81.894 81.894-63.545 97.144-40.748 107.552-14.535q82.45 0 157.513 32.091t129.474 86.343 86.343 129.474 32.091 157.513-32.091 157.513-86.343 129.474-129.474 86.343-157.513 32.091q-54.969 0-107.552-14.535t-97.144-40.748-81.894-63.545-63.545-81.894-40.748-96.985-14.535-107.709zM412.711 696.237q0 6.99 4.765 11.756t11.756 4.846h198.579q6.99 0 11.756-4.846t4.846-11.756v-66.167q0-6.592-4.846-11.597t-11.756-4.926h-49.647v-215.182q0-6.911-4.765-11.756t-11.756-4.765h-132.414q-6.911 0-11.756 4.765t-4.765 11.756v66.246q0 6.911 4.765 11.756t11.756 4.765h49.646v132.414h-49.646q-6.911 0-11.756 4.926t-4.765 11.597v66.167zM478.876 332.202q0 6.99 4.846 11.756t11.756 4.765h66.167q6.99 0 11.756-4.765t4.765-11.756v-66.167q0-6.99-4.765-11.756t-11.756-4.846h-66.167q-6.99 0-11.756 4.846t-4.846 11.756v66.167z"/>\
</symbol></defs></svg>\
                     <!--load fonticon glyph-e004-->\
                     <use xlink:href="#icon-glyph-e004"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page721987303"] .border-wrapper,\
         		body[data-current-page-id="page721987303"] .simulation-container {\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page721987303"] .border-wrapper,\
         		body.has-frame[data-current-page-id="page721987303"] .simulation-container {\
         			height:660px;\
         		}\
         		\
         		body[data-current-page-id="page721987303"] .svg-border-1366-660 {\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page721987303"] .border-wrapper .border-div {\
         			width:1366px;\
         			height:660px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page721987303",\
      			"name": "Login",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":660,\
      			"parentFolder": "",\
      			"frame": "browser",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
</div>');