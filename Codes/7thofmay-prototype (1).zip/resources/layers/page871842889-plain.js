rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__page871842889-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page871842889" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page871842889-layer-chart729723563" style="position: absolute; left: 140px; top: 55px; width: 285px; height: 225px" data-stencil-type="static.chart" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="chart729723563" data-review-reference-id="chart729723563">\
            <div class="stencil-wrapper" style="width: 285px; height: 225px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg overflow="hidden" style="height: 225px;width:285px;" viewBox="0 0 285 225" width="285" height="225">\
                     <g width="285" height="225">\
                        <g xmlns:xi="http://www.w3.org/2001/XInclude" transform="scale(1.5833333333333333, 1.5)">\
                           <rect x="0" y="0" width="180" height="150" style="fill:white;stroke:none;"></rect>\
                           <g name="bar" style="stroke:black;fill:none;stroke-width:1px;">\
                              <path d="M 9,3 L 9,140 L 177,140"></path>\
                              <path d="M 168,135 L 178,140 L 168,145"></path>\
                              <path d="M 4,13 L 9,3 L 14,13"></path>\
                              <rect width="19" height="77" x="19" y="63"></rect>\
                              <rect width="19" height="93" x="47" y="47"></rect>\
                              <rect width="19" height="84" x="76" y="56"></rect>\
                              <rect width="19" height="51" x="104" y="89"></rect>\
                              <rect width="19" height="109" x="133" y="31"></rect>\
                           </g>\
                        </g>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page871842889-layer-text833289737" style="position: absolute; left: 255px; top: 290px; width: 74px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text833289737" data-review-reference-id="text833289737">\
            <div class="stencil-wrapper" style="width: 74px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:79px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Daily sales</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page871842889-layer-1725107584" style="position: absolute; left: 520px; top: 55px; width: 285px; height: 225px" data-stencil-type="static.chart" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="1725107584" data-review-reference-id="1725107584">\
            <div class="stencil-wrapper" style="width: 285px; height: 225px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg overflow="hidden" style="height: 225px;width:285px;" viewBox="0 0 285 225" width="285" height="225">\
                     <g width="285" height="225">\
                        <g xmlns:xi="http://www.w3.org/2001/XInclude" transform="scale(1.5833333333333333, 1.5)">\
                           <rect x="0" y="0" width="180" height="150" style="fill:white;stroke:none;"></rect>\
                           <g name="bar" style="stroke:black;fill:none;stroke-width:1px;">\
                              <path d="M 9,3 L 9,140 L 177,140"></path>\
                              <path d="M 168,135 L 178,140 L 168,145"></path>\
                              <path d="M 4,13 L 9,3 L 14,13"></path>\
                              <rect width="19" height="77" x="19" y="63"></rect>\
                              <rect width="19" height="93" x="47" y="47"></rect>\
                              <rect width="19" height="84" x="76" y="56"></rect>\
                              <rect width="19" height="51" x="104" y="89"></rect>\
                              <rect width="19" height="109" x="133" y="31"></rect>\
                           </g>\
                        </g>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page871842889-layer-1032191581" style="position: absolute; left: 625px; top: 290px; width: 87px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1032191581" data-review-reference-id="1032191581">\
            <div class="stencil-wrapper" style="width: 87px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:92px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p class="none" style="font-size: 14px;">Weekly Sale </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page871842889-layer-1848669920" style="position: absolute; left: 910px; top: 55px; width: 285px; height: 225px" data-stencil-type="static.chart" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="1848669920" data-review-reference-id="1848669920">\
            <div class="stencil-wrapper" style="width: 285px; height: 225px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg overflow="hidden" style="height: 225px;width:285px;" viewBox="0 0 285 225" width="285" height="225">\
                     <g width="285" height="225">\
                        <g xmlns:xi="http://www.w3.org/2001/XInclude" transform="scale(1.5833333333333333, 1.5)">\
                           <rect x="0" y="0" width="180" height="150" style="fill:white;stroke:none;"></rect>\
                           <g name="bar" style="stroke:black;fill:none;stroke-width:1px;">\
                              <path d="M 9,3 L 9,140 L 177,140"></path>\
                              <path d="M 168,135 L 178,140 L 168,145"></path>\
                              <path d="M 4,13 L 9,3 L 14,13"></path>\
                              <rect width="19" height="77" x="19" y="63"></rect>\
                              <rect width="19" height="93" x="47" y="47"></rect>\
                              <rect width="19" height="84" x="76" y="56"></rect>\
                              <rect width="19" height="51" x="104" y="89"></rect>\
                              <rect width="19" height="109" x="133" y="31"></rect>\
                           </g>\
                        </g>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page871842889-layer-1974026643" style="position: absolute; left: 1015px; top: 290px; width: 94px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1974026643" data-review-reference-id="1974026643">\
            <div class="stencil-wrapper" style="width: 94px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:99px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p class="none" style="font-size: 14px;">Monthly Sales</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page871842889-layer-chart151111826" style="position: absolute; left: 145px; top: 335px; width: 275px; height: 235px" data-stencil-type="static.chart" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="chart151111826" data-review-reference-id="chart151111826">\
            <div class="stencil-wrapper" style="width: 275px; height: 235px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg overflow="hidden" style="height: 235px;width:275px;" viewBox="0 0 275 235" width="275" height="235">\
                     <g width="275" height="235">\
                        <g xmlns:xi="http://www.w3.org/2001/XInclude" transform="scale(1.5277777777777777, 1.5666666666666667)">\
                           <rect x="0" y="0" width="180" height="150" style="fill:white;stroke:none;"></rect>\
                           <g name="line" style="fill:none;stroke:black;stroke-width:1px;">\
                              <path d="M 9,3 L 9,140 L 168,140 L 176,140"></path>\
                              <path d="M 167,135 L 177,140 L 167,145"></path>\
                              <path d="M 4,13 L 9,3 L 14,13"></path>\
                              <path d="M 9,140 L 30,112 L 46,98 L 54,106 L 68,89 L 74,82 L 76,74 L 82,67 L 92,96 L 97,76 L 106,66 L 111,50 L 122,37 L 127,45 L 129,51 L 139,51 L 151,29 L 159,26 L 161,16 L 166,12"></path>\
                              <path d="M 10,140 L 18,107 L 29,91 L 34,73 L 44,80 L 51,55 L 62,52 L 74,34 L 86,51 L 99,43 L 111,59 L 121,70 L 128,98 L 139,119 L 147,103 L 154,125 L 165,136"></path>\
                           </g>\
                        </g>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page871842889-layer-1296010172" style="position: absolute; left: 240px; top: 575px; width: 81px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1296010172" data-review-reference-id="1296010172">\
            <div class="stencil-wrapper" style="width: 81px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:86px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Yearly sales</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page871842889-layer-chart887861581" style="position: absolute; left: 535px; top: 355px; width: 260px; height: 205px" data-stencil-type="static.chart" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="chart887861581" data-review-reference-id="chart887861581">\
            <div class="stencil-wrapper" style="width: 260px; height: 205px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg overflow="hidden" style="height: 205px;width:260px;" viewBox="0 0 260 205" width="260" height="205">\
                     <g width="260" height="205">\
                        <g xmlns:xi="http://www.w3.org/2001/XInclude" transform="scale(1.4444444444444444, 1.3666666666666667)">\
                           <rect x="0" y="0" width="180" height="150" style="fill:white;stroke:none;"></rect>\
                           <g name="bar" style="stroke:black;fill:none;stroke-width:1px;">\
                              <path d="M 9,3 L 9,140 L 177,140"></path>\
                              <path d="M 168,135 L 178,140 L 168,145"></path>\
                              <path d="M 4,13 L 9,3 L 14,13"></path>\
                              <rect width="19" height="77" x="19" y="63"></rect>\
                              <rect width="19" height="93" x="47" y="47"></rect>\
                              <rect width="19" height="84" x="76" y="56"></rect>\
                              <rect width="19" height="51" x="104" y="89"></rect>\
                              <rect width="19" height="109" x="133" y="31"></rect>\
                           </g>\
                        </g>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page871842889-layer-426375695" style="position: absolute; left: 535px; top: 355px; width: 260px; height: 205px" data-stencil-type="static.chart" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="426375695" data-review-reference-id="426375695">\
            <div class="stencil-wrapper" style="width: 260px; height: 205px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg overflow="hidden" style="height: 205px;width:260px;" viewBox="0 0 260 205" width="260" height="205">\
                     <g width="260" height="205">\
                        <g xmlns:xi="http://www.w3.org/2001/XInclude" transform="scale(1.4444444444444444, 1.3666666666666667)">\
                           <rect x="0" y="0" width="180" height="150" style="fill:white;stroke:none;"></rect>\
                           <g name="bar" style="stroke:black;fill:none;stroke-width:1px;">\
                              <path d="M 9,3 L 9,140 L 177,140"></path>\
                              <path d="M 168,135 L 178,140 L 168,145"></path>\
                              <path d="M 4,13 L 9,3 L 14,13"></path>\
                              <rect width="19" height="77" x="19" y="63"></rect>\
                              <rect width="19" height="93" x="47" y="47"></rect>\
                              <rect width="19" height="84" x="76" y="56"></rect>\
                              <rect width="19" height="51" x="104" y="89"></rect>\
                              <rect width="19" height="109" x="133" y="31"></rect>\
                           </g>\
                        </g>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page871842889-layer-2136424611" style="position: absolute; left: 600px; top: 575px; width: 127px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2136424611" data-review-reference-id="2136424611">\
            <div class="stencil-wrapper" style="width: 127px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:132px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Top Selling Product</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page871842889-layer-943906455" style="position: absolute; left: 930px; top: 355px; width: 260px; height: 205px" data-stencil-type="static.chart" data-interactive-element-type="static.chart" class="chart stencil mobile-interaction-potential-trigger " data-stencil-id="943906455" data-review-reference-id="943906455">\
            <div class="stencil-wrapper" style="width: 260px; height: 205px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="">\
                  <svg overflow="hidden" style="height: 205px;width:260px;" viewBox="0 0 260 205" width="260" height="205">\
                     <g width="260" height="205">\
                        <g xmlns:xi="http://www.w3.org/2001/XInclude" transform="scale(1.4444444444444444, 1.3666666666666667)">\
                           <rect x="0" y="0" width="180" height="150" style="fill:white;stroke:none;"></rect>\
                           <g name="bar" style="stroke:black;fill:none;stroke-width:1px;">\
                              <path d="M 9,3 L 9,140 L 177,140"></path>\
                              <path d="M 168,135 L 178,140 L 168,145"></path>\
                              <path d="M 4,13 L 9,3 L 14,13"></path>\
                              <rect width="19" height="77" x="19" y="63"></rect>\
                              <rect width="19" height="93" x="47" y="47"></rect>\
                              <rect width="19" height="84" x="76" y="56"></rect>\
                              <rect width="19" height="51" x="104" y="89"></rect>\
                              <rect width="19" height="109" x="133" y="31"></rect>\
                           </g>\
                        </g>\
                     </g>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page871842889-layer-816363635" style="position: absolute; left: 985px; top: 575px; width: 138px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="816363635" data-review-reference-id="816363635">\
            <div class="stencil-wrapper" style="width: 138px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:143px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Least Selling Product</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page871842889-layer-button206247753" style="position: absolute; left: 630px; top: 615px; width: 60px; height: 30px" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="button206247753" data-review-reference-id="button206247753">\
            <div class="stencil-wrapper" style="width: 60px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:60px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Next</button></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 60px; height: 30px"></div>\
            <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					Raven.context(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-page871842889-layer-button206247753\', \'interaction22286355\', {"button":"left","id":"action793392114","numberOfFinger":"1","type":"click"},  \
							[\
								{"delay":"0","id":"reaction371957156","options":"withoutReloadOnly","target":"page791573617","transition":"none","type":"showPage"}\
							]\
						);\
					});\
				});\
			</script></div>\
         </div>\
         <div id="__containerId__-page871842889-layer-menu552644809" style="position: absolute; left: 0px; top: 30px; width: 1366px; height: 20px" data-stencil-type="default.menu" data-interactive-element-type="default.menu" class="menu stencil mobile-interaction-potential-trigger " data-stencil-id="menu552644809" data-review-reference-id="menu552644809">\
            <div class="stencil-wrapper" style="width: 1366px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="yui-skin-sam  menu" style="width:1366px;height:20px;" title="">\
                  <div id="__containerId__-page871842889-layer-menu552644809-menu-container"></div>\
               </div><script xmlns="http://www.w3.org/1999/xhtml" type="text/javascript">Raven.context(function () {\
			rabbit.stencils.menu.setupMenu("__containerId__-page871842889-layer-menu552644809", \'[{"text":"Menu","submenu":{"id":"__containerId__-page871842889-layer-menu552644809-0","itemdata":[{"text":"Product List ","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page381066001"}},{"text":"Transaction list","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page497637931"}},{"text":"Process Order","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page11821914"}}]}},{"text":"Edit ","submenu":{"id":"__containerId__-page871842889-layer-menu552644809-1","itemdata":[{"text":"add ","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page608432602"}},{"text":"Update","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page906964771"}},{"text":"Delete","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page835478005"}}]}}]\', \'horizontal\');\
		});</script></div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page871842889"] .border-wrapper,\
         		body[data-current-page-id="page871842889"] .simulation-container {\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page871842889"] .border-wrapper,\
         		body.has-frame[data-current-page-id="page871842889"] .simulation-container {\
         			height:660px;\
         		}\
         		\
         		body[data-current-page-id="page871842889"] .svg-border-1366-660 {\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page871842889"] .border-wrapper .border-div {\
         			width:1366px;\
         			height:660px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page871842889",\
      			"name": "Dashboard",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":660,\
      			"parentFolder": "",\
      			"frame": "browser",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
</div>');