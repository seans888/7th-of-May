rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__page906964771-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page906964771" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page906964771-layer-combobox170637758" style="position: absolute; left: 155px; top: 185px; width: 150px; height: 30px" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="combobox170637758" data-review-reference-id="combobox170637758">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page906964771-layer-combobox170637758select" style="width:150px;height:30px;" title="">\
                     <option title="">First Product</option>\
                     <option title="">Second Product</option>\
                     <option title="">Third Product</option></select></div>\
            </div>\
         </div>\
         <div id="__containerId__-page906964771-layer-textinput59605962" style="position: absolute; left: 440px; top: 185px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput59605962" data-review-reference-id="textinput59605962">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page906964771-layer-textinput59605962input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page906964771-layer-textinput90994454" style="position: absolute; left: 695px; top: 185px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput90994454" data-review-reference-id="textinput90994454">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page906964771-layer-textinput90994454input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page906964771-layer-text802215672" style="position: absolute; left: 155px; top: 140px; width: 84px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text802215672" data-review-reference-id="text802215672">\
            <div class="stencil-wrapper" style="width: 84px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:89px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Product List:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page906964771-layer-text559708227" style="position: absolute; left: 445px; top: 140px; width: 62px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text559708227" data-review-reference-id="text559708227">\
            <div class="stencil-wrapper" style="width: 62px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:67px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Quantity:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page906964771-layer-text372400358" style="position: absolute; left: 695px; top: 140px; width: 42px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text372400358" data-review-reference-id="text372400358">\
            <div class="stencil-wrapper" style="width: 42px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:47px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Price:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page906964771-layer-1764419144" style="position: absolute; left: 155px; top: 260px; width: 150px; height: 30px" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="1764419144" data-review-reference-id="1764419144">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page906964771-layer-1764419144select" style="width:150px;height:30px;" title="">\
                     <option title="">First Product</option>\
                     <option title="">Second Product</option>\
                     <option title="">Third Product</option></select></div>\
            </div>\
         </div>\
         <div id="__containerId__-page906964771-layer-24370080" style="position: absolute; left: 440px; top: 260px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="24370080" data-review-reference-id="24370080">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page906964771-layer-24370080input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page906964771-layer-744494858" style="position: absolute; left: 695px; top: 260px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="744494858" data-review-reference-id="744494858">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page906964771-layer-744494858input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page906964771-layer-37931109" style="position: absolute; left: 155px; top: 340px; width: 150px; height: 30px" data-stencil-type="default.combobox" data-interactive-element-type="default.combobox" class="combobox stencil mobile-interaction-potential-trigger " data-stencil-id="37931109" data-review-reference-id="37931109">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page906964771-layer-37931109select" style="width:150px;height:30px;" title="">\
                     <option title="">First Product</option>\
                     <option title="">Second Product</option>\
                     <option title="">Third Product</option></select></div>\
            </div>\
         </div>\
         <div id="__containerId__-page906964771-layer-767302302" style="position: absolute; left: 440px; top: 340px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="767302302" data-review-reference-id="767302302">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page906964771-layer-767302302input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page906964771-layer-2074366960" style="position: absolute; left: 695px; top: 340px; width: 150px; height: 30px" data-stencil-type="default.textinput" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="2074366960" data-review-reference-id="2074366960">\
            <div class="stencil-wrapper" style="width: 150px; height: 30px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><input type="text" id="__containerId__-page906964771-layer-2074366960input" value="" style="width:148px;height:28px;padding: 0px;border-width:1px;" class="" onsubmit="debugger" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page906964771-layer-button250340768" style="position: absolute; left: 485px; top: 485px; width: 69px; height: 30px" data-stencil-type="default.button" data-interactive-element-type="default.button" class="button pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="button250340768" data-review-reference-id="button250340768">\
            <div class="stencil-wrapper" style="width: 69px; height: 30px">\
               <div xmlns:helper="java:it.rapidrabb.editor.stencils.helpers.StencilHelper" xmlns="http://www.w3.org/1999/xhtml" title=""><button type="button" style="width:69px;height:30px;font-size:1em;background-color:#d9d9d9;padding-left: 0px; padding-right: 0px;" xml:space="preserve" title="">Update</button></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 69px; height: 30px"></div>\
            <div xmlns:json="http://json.org/" xmlns="http://www.w3.org/1999/xhtml"><script type="text/javascript">\
				$(document).ready(function(){\
					Raven.context(function () {\
						rabbit.interaction.manager.registerInteraction(\'__containerId__-page906964771-layer-button250340768\', \'interaction67651503\', {"button":"left","id":"action984185844","numberOfFinger":"1","type":"click"},  \
							[\
								{"delay":"0","id":"reaction491789032","options":"withoutReloadOnly","target":"page835478005","transition":"none","type":"showPage"}\
							]\
						);\
					});\
				});\
			</script></div>\
         </div>\
         <div id="__containerId__-page906964771-layer-text630630149" style="position: absolute; left: 575px; top: 70px; width: 228px; height: 37px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text630630149" data-review-reference-id="text630630149">\
            <div class="stencil-wrapper" style="width: 228px; height: 37px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:233px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12">\
                        <p><span style="font-size: 32px;">Update Product</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page906964771-layer-777758188" style="position: absolute; left: 5px; top: 50px; width: 1366px; height: 20px" data-stencil-type="default.menu" data-interactive-element-type="default.menu" class="menu stencil mobile-interaction-potential-trigger " data-stencil-id="777758188" data-review-reference-id="777758188">\
            <div class="stencil-wrapper" style="width: 1366px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="yui-skin-sam  menu" style="width:1366px;height:20px;" title="">\
                  <div id="__containerId__-page906964771-layer-777758188-menu-container"></div>\
               </div><script xmlns="http://www.w3.org/1999/xhtml" type="text/javascript">Raven.context(function () {\
			rabbit.stencils.menu.setupMenu("__containerId__-page906964771-layer-777758188", \'[{"text":"Menu","submenu":{"id":"menu552644809-0","itemdata":[{"text":"Product List ","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page381066001"}},{"text":"Transaction list","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page497637931"}},{"text":"Process Order","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page11821914"}}]}},{"text":"Edit ","submenu":{"id":"menu552644809-1","itemdata":[{"text":"add ","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page608432602"}},{"text":"Update","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page906964771"}},{"text":"Delete","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page835478005"}}]}}]\', \'horizontal\');\
		});</script></div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page906964771"] .border-wrapper,\
         		body[data-current-page-id="page906964771"] .simulation-container {\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page906964771"] .border-wrapper,\
         		body.has-frame[data-current-page-id="page906964771"] .simulation-container {\
         			height:660px;\
         		}\
         		\
         		body[data-current-page-id="page906964771"] .svg-border-1366-660 {\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page906964771"] .border-wrapper .border-div {\
         			width:1366px;\
         			height:660px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page906964771",\
      			"name": "Inventory(Update)",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":660,\
      			"parentFolder": "",\
      			"frame": "browser",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
</div>');