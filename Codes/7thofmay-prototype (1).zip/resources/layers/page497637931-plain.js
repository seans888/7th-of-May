rabbit.data.layerStore.addLayerFromHtml('<div xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" id="__containerId__page497637931-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page497637931" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page497637931-layer-listview7685741" style="position: absolute; left: 75px; top: 180px; width: 220px; height: 390px" data-stencil-type="default.listview" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="listview7685741" data-review-reference-id="listview7685741">\
            <div class="stencil-wrapper" style="width: 220px; height: 390px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page497637931-layer-listview7685741select" style="width:220px; height:390px;" size="2" title="" multiple="multiple">\
                     <addScrollListener></addScrollListener>\
                     <option title="">Marco Joaquin B. Po</option>\
                     <option title="">Joseph Alovera</option></select></div>\
            </div>\
         </div>\
         <div id="__containerId__-page497637931-layer-text864992852" style="position: absolute; left: 75px; top: 150px; width: 112px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text864992852" data-review-reference-id="text864992852">\
            <div class="stencil-wrapper" style="width: 112px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:117px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Customer Name:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page497637931-layer-text440851286" style="position: absolute; left: 570px; top: 85px; width: 188px; height: 37px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text440851286" data-review-reference-id="text440851286">\
            <div class="stencil-wrapper" style="width: 188px; height: 37px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:193px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.textHeadline12">\
                        <p><span style="font-size: 32px;">Transactions</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page497637931-layer-1953558234" style="position: absolute; left: 550px; top: 185px; width: 220px; height: 390px" data-stencil-type="default.listview" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="1953558234" data-review-reference-id="1953558234">\
            <div class="stencil-wrapper" style="width: 220px; height: 390px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page497637931-layer-1953558234select" style="width:220px; height:390px;" size="2" title="" multiple="multiple">\
                     <addScrollListener></addScrollListener>\
                     <option title="">Cash</option>\
                     <option title="">Credit Card</option>\
                     <option title=""></option></select></div>\
            </div>\
         </div>\
         <div id="__containerId__-page497637931-layer-text105239926" style="position: absolute; left: 550px; top: 150px; width: 103px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text105239926" data-review-reference-id="text105239926">\
            <div class="stencil-wrapper" style="width: 103px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:108px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p class="none" style="font-size: 14px;">Payment Type: </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page497637931-layer-1232116199" style="position: absolute; left: 1020px; top: 180px; width: 220px; height: 390px" data-stencil-type="default.listview" data-interactive-element-type="default.listview" class="listview stencil mobile-interaction-potential-trigger " data-stencil-id="1232116199" data-review-reference-id="1232116199">\
            <div class="stencil-wrapper" style="width: 220px; height: 390px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title=""><select id="__containerId__-page497637931-layer-1232116199select" style="width:220px; height:390px;" size="2" title="" multiple="multiple">\
                     <addScrollListener></addScrollListener>\
                     <option title="">Paid</option>\
                     <option title="">Not yet paid</option></select></div>\
            </div>\
         </div>\
         <div id="__containerId__-page497637931-layer-text53504867" style="position: absolute; left: 1020px; top: 150px; width: 109px; height: 17px" data-stencil-type="default.text2" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text53504867" data-review-reference-id="text53504867">\
            <div class="stencil-wrapper" style="width: 109px; height: 17px">\
               <div xmlns="http://www.w3.org/1999/xhtml" title="" style="width:114px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2">\
                        <p style="font-size: 14px;">Payment Status:</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page497637931-layer-1643826204" style="position: absolute; left: -5px; top: 60px; width: 1366px; height: 20px" data-stencil-type="default.menu" data-interactive-element-type="default.menu" class="menu stencil mobile-interaction-potential-trigger " data-stencil-id="1643826204" data-review-reference-id="1643826204">\
            <div class="stencil-wrapper" style="width: 1366px; height: 20px">\
               <div xmlns="http://www.w3.org/1999/xhtml" class="yui-skin-sam  menu" style="width:1366px;height:20px;" title="">\
                  <div id="__containerId__-page497637931-layer-1643826204-menu-container"></div>\
               </div><script xmlns="http://www.w3.org/1999/xhtml" type="text/javascript">Raven.context(function () {\
			rabbit.stencils.menu.setupMenu("__containerId__-page497637931-layer-1643826204", \'[{"text":"Menu","submenu":{"id":"menu552644809-0","itemdata":[{"text":"Product List ","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page381066001"}},{"text":"Transaction list","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page497637931"}},{"text":"Process Order","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page11821914"}}]}},{"text":"Edit ","submenu":{"id":"menu552644809-1","itemdata":[{"text":"add ","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page608432602"}},{"text":"Update","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page906964771"}},{"text":"Delete","onclick":{"fn":rabbit.result.manager.menuClick,"obj":"page835478005"}}]}}]\', \'horizontal\');\
		});</script></div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page497637931"] .border-wrapper,\
         		body[data-current-page-id="page497637931"] .simulation-container {\
         			width:1366px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page497637931"] .border-wrapper,\
         		body.has-frame[data-current-page-id="page497637931"] .simulation-container {\
         			height:660px;\
         		}\
         		\
         		body[data-current-page-id="page497637931"] .svg-border-1366-660 {\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page497637931"] .border-wrapper .border-div {\
         			width:1366px;\
         			height:660px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page497637931",\
      			"name": "Transaction list",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":1366,\
      			"height":660,\
      			"parentFolder": "",\
      			"frame": "browser",\
      			"frameOrientation": "landscape"\
      		}\
      	\
   </div>\
</div>');